package testScript;

import generic.Base_Class;



import org.openqa.selenium.By;

import org.testng.annotations.Test;

public class Scenario_Search extends Base_Class {
	
	@Test(dataProvider = "Invalid_Search", dataProviderClass = dataProvider.DP_Search.class)
	public void InvalidSearch(String TC_ID, String Order, String Search_Item, String expected)
	{
		driver.findElement(By.id("srchword")).sendKeys(Search_Item);
		driver.findElement(By.className("newsrchbtn")).click();
		String invalidsearch = driver.findElement(By.className("sorrymsg")).getText();
		System.out.println(invalidsearch);
	}
	
	@Test(dataProvider = "valid_Search", dataProviderClass = dataProvider.DP_Search.class)
	public void validSearch(String TC_ID, String Order, String Search_Item, String expected)
	{
		driver.findElement(By.id("srchword")).sendKeys(Search_Item);
		driver.findElement(By.className("newsrchbtn")).click();
		String validsearch = driver.findElement(By.id("find")).getText();
		System.out.println(validsearch);
	}

}
